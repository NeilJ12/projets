from bases import *
from possibles import *
from merge import *
import pygame

from pygame.locals import *

n = 5

WHITE = (255,255,255)
BLUE = (0,0,255)
GREEN = (0,255,0)
RED = (255,0,0)
BLACK = (0,0,0)
PINK = (234, 30, 99)
PURPLE = (156, 39, 176)
DEEP_PURPLE = (103, 58, 183)
TEAL = (0, 150, 136)
L_GREEN = (139, 195, 74)
ORANGE = (255, 152, 0)
DEEP_ORANGE = (255, 87, 34)
BROWN = (121, 85, 72)

colour_dict = {0: BROWN, 1:GREEN, 2:TEAL, 3:DEEP_PURPLE, 4:PURPLE, 5:DEEP_ORANGE, 6:RED, 7:BLUE, 8:L_GREEN, 9:PINK, 10:ORANGE}

def getColour(i):
    return colour_dict[i]

def displayGraph(board, Surface, i, j, select):
    if select == True:
        pygame.draw.rect(Surface, WHITE, ((i + 1) * 60, (j + 1) * 60, 60, 60))
        label = font.render(str(board[i][j]), 0, BLACK)
        Surface.blit(label, (((i + 1) * 60) + 25, ((j + 1) * 60) + 23))
    else:
        Color = getColour(board[i][j])
        pygame.draw.rect(Surface, Color, ((i + 1) * 60, (j + 1) * 60, 60, 60))
        label = font.render(str(board[i][j]), 0, BLACK)
        Surface.blit(label, (((i + 1) * 60) + 25, ((j + 1) * 60) + 23))

def displayT(board, n, Surface):
    for i in range(n):
        for j in range(n):
            if (i, j) not in L:
                displayGraph(board, Surface, i, j, False)
            else:
                displayGraph(board, Surface, i, j, True)

def score(board, n):

    max = max_tableau(n, board)
    label1 = font.render("Score", 0, WHITE)
    label_scr = font.render(str(max), 0, WHITE)
    Surface.blit(label1, (500, 120))
    pygame.draw.rect(Surface, BLACK, (510, 140, 30, 30))
    Surface.blit(label_scr, (520, 150))


pygame.init()

font = pygame.font.SysFont("monospace", 25)

son = pygame.mixer.Sound("son.wav")

Surface = pygame.display.set_mode((900, 600))

L = []

inProgress = True

while inProgress:

    for event in pygame.event.get():

        if event.type == MOUSEBUTTONDOWN:
            R_Play = pygame.draw.rect(Surface, BLACK, (490, 190, 100, 50))
            R_Quit = pygame.draw.rect(Surface, BLACK, (490, 290, 100, 50))

            if R_Quit.collidepoint(event.pos):
                inProgress = False

            if R_Play.collidepoint(event.pos):
                son.stop()
                Surface.fill(BLACK)
                board = newBoard(n, probabilite)

            x1, y1 = event.pos
            x2 = (x1 // 60) - 1
            y2 = (y1 // 60) - 1


            if (x2, y2) not in L:
                L = [(x2, y2)]
                current = (x2, y2)
                for a in L:
                    propagation(board, L, a, n)
                print(L)

                if len(L) <= 1:
                    L = []
                    continue
            else:
                modification(L, board, (x2, y2))
                gravity(board, n, probabilite)
                L = []


        if event.type == QUIT:
            inProgress = False
            break



        if max_tableau(n, board) == 10 or jouable(n, board) == False:

            if max_tableau(n, board) == 10:
                son.play()
                labelP = font.render("Play Again", 0, WHITE)
                pygame.draw.rect(Surface, BLACK, (490, 190, 100, 50))
                Surface.blit(labelP, (500, 200))
                labelQ = font.render("Quit", 0, WHITE)
                pygame.draw.rect(Surface, BLACK, (490, 290, 100, 50))
                Surface.blit(labelQ, (500, 300))

            if jouable(n, board) == False:
                labelP = font.render("Play Again", 0, WHITE)
                pygame.draw.rect(Surface, BLACK, (490, 190, 100, 50))
                Surface.blit(labelP, (500, 200))
                labelQ = font.render("Quit", 0, WHITE)
                pygame.draw.rect(Surface, BLACK, (490, 290, 100, 50))
                Surface.blit(labelQ, (500, 300))


        displayT(board, n, Surface)
        score(board, n)


    pygame.display.update()

pygame.quit()
