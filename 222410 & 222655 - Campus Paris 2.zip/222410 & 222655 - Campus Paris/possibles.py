def case_adj(board, n, i, j):     # On check s'il existe une case adjacente (c-à-d à gauche, à droite, en haut ou en bas) avec la même valeur que la case concernée

    if i > 0 and i < n-1 and j > 0 and j < n-1:
        if board[i][j - 1] == board[i][j] or board[i - 1][j] == board[i][j] or board[i][j + 1] == board[i][j] or board[i + 1][j] == board[i][j]:
            return True
        else:
            return False

    if i == 0 and j > 0 and j < n-1:
        if board[i][j - 1] == board[i][j] or board[i][j + 1] == board[i][j] or board[i + 1][j] == board[i][j]:
            return True
        else:
            return False

    if i == n-1 and j > 0 and j < n-1:
        if board[i][j - 1] == board[i][j] or board[i - 1][j] == board[i][j] or board[i][j + 1] == board[i][j]:
            return True
        else:
            return False

    if i > 0 and i < n-1 and j == 0:
        if board[i - 1][j] == board[i][j] or board[i][j + 1] == board[i][j] or board[i + 1][j] == board[i][j]:
            return True
        else:
            return False

    if i > 0 and i < n-1 and j == n-1:
        if board[i][j - 1] == board[i][j] or board[i - 1][j] == board[i][j] or board[i + 1][j] == board[i][j]:
            return True
        else:
            return False

    if i == 0 and j == 0:
        if board[i][j + 1] == board[i][j] or board[i + 1][j] == board[i][j]:
            return True
        else:
            return False

    if i == 0 and j == n-1:
        if board[i][j - 1] == board[i][j] or board[i + 1][j] == board[i][j]:
            return True
        else:
            return False

    if i == n-1 and j == 0:
        if board[i - 1][j] == board[i][j] or board[i][j + 1] == board[i][j]:
            return True
        else:
            return False

    if i == n-1 and j == n-1:
        if board[i][j - 1] == board[i][j] or board[i - 1][j] == board[i][j]:
            return True
        else:
            return False

def jouable(n, board):

    a = False

    for i in range(0, n):
        for j in range(0, n):
            if case_adj(board, n, i, j) == True:
                a = True
                break

    return a

def max_tableau(n, board):

    lst = []
    for i in range (0, n):
        lst.append(max(board[i]))  #On met le max de chaque sous-liste dans une liste finale, et puis on prend le max de cette liste finale. Ce sera donc le max de la grande liste.
    return max(lst)