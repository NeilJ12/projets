from random import *

n = 5

def probabilite(x1, x2, x3):

    number = uniform(0,1)
    if number <= x1:
        return 4
    elif number > x1 and number <= x2:
        return 3
    elif number > x2 and number <= x3:
        return 2
    else:
        return 1

def newBoard(n, probabilite):

    liste = []
    for i in range(0, n):
        liste_int = []
        for j in range(0, n):
            x = probabilite(0.05, 0.30, 0.6)
            liste_int.append(x)

        liste.append(liste_int)

    return liste

def display(board, n):

    for i in range(0, n):
        a = ""
        for j in range(0, n):
            a += str(board[i][j]) + " "
        print(a)

