from possibles import *
from bases import *


def propagation(board, L, current, n):

    i, j = current
    if i > 0 and i < n - 1 and j > 0 and j < n - 1:

        if board[i][j - 1] == board[i][j]:
            if (i, j - 1) not in L:
                L.append((i, j - 1))

        if board[i - 1][j] == board[i][j]:
            if (i - 1, j) not in L:
                L.append((i - 1, j))

        if board[i][j + 1] == board[i][j]:
            if (i, j + 1) not in L:
                L.append((i, j + 1))

        if board[i + 1][j] == board[i][j]:
            if (i + 1, j) not in L:
                L.append((i + 1, j))

    if i == 0 and j > 0 and j < n - 1:

        if board[i][j - 1] == board[i][j]:
            if (i, j - 1) not in L:
                L.append((i, j - 1))

        if board[i][j + 1] == board[i][j]:
            if (i, j + 1) not in L:
                L.append((i, j + 1))

        if board[i + 1][j] == board[i][j]:
            if (i + 1, j) not in L:
                L.append((i + 1, j))

    if i == n - 1 and j > 0 and j < n - 1:

        if board[i][j - 1] == board[i][j]:
            if (i, j - 1) not in L:
                L.append((i, j - 1))

        if board[i - 1][j] == board[i][j]:
            if (i - 1, j) not in L:
                L.append((i - 1, j))

        if board[i][j + 1] == board[i][j]:
            if (i, j + 1) not in L:
                L.append((i, j + 1))

    if i > 0 and i < n - 1 and j == 0:

        if board[i - 1][j] == board[i][j]:
            if (i - 1, j) not in L:
                L.append((i - 1, j))

        if board[i][j + 1] == board[i][j]:
            if (i, j + 1) not in L:
                L.append((i, j + 1))

        if board[i + 1][j] == board[i][j]:
            if (i + 1, j) not in L:
                L.append((i + 1, j))

    if i > 0 and i < n - 1 and j == n - 1:

        if board[i][j - 1] == board[i][j]:
            if (i, j - 1) not in L:
                L.append((i, j - 1))

        if board[i - 1][j] == board[i][j]:
            if (i - 1, j) not in L:
                L.append((i - 1, j))

        if board[i + 1][j] == board[i][j]:
            if (i + 1, j) not in L:
                L.append((i + 1, j))

    if i == 0 and j == 0:

        if board[i][j + 1] == board[i][j]:
            if (i, j + 1) not in L:
                L.append((i, j + 1))
        if board[i + 1][j] == board[i][j]:
            if (i + 1, j) not in L:
                L.append((i + 1, j))

    if i == 0 and j == n - 1:

        if board[i][j - 1] == board[i][j]:
            if (i, j - 1) not in L:
                L.append((i, j - 1))

        if board[i + 1][j] == board[i][j]:
            if (i + 1, j) not in L:
                L.append((i + 1, j))

    if i == n - 1 and j == 0:

        if board[i - 1][j] == board[i][j]:
            if (i - 1, j) not in L:
                L.append((i - 1, j))

        if board[i][j + 1] == board[i][j]:
            if (i, j + 1) not in L:
                L.append((i, j + 1))

    if i == n - 1 and j == n - 1:

        if board[i][j - 1] == board[i][j]:
            if (i, j - 1) not in L:
                L.append((i, j - 1))

        if board[i - 1][j] == board[i][j]:
            if (i - 1, j) not in L:
                L.append((i - 1, j))


n=5

board = newBoard(n, probabilite)
display(board, n)
print()
print(board)

def modification(L,board,current):
    x, y = current
    c = board[x][y]
    for b in L:
        i,j=b
        board[i][j] = 0
    i,j= x, y
    board[i][j] = c + 1

def gravity(board, n, probabilite):

    j = 3

    while j >= 0:
        for i in range(0, n):
            for x in range (1, n-j):
                if board[i][j+x] == 0:
                    board[i][j+x] = board[i][j+x-1]
                    board[i][j+x-1] = 0
        j -= 1

    display(board, n)
    print()

    for i in range(0, n):
        for j in range(0, n):
            if board[i][j] == 0:
                board[i][j] = probabilite(0.05, 0.30, 0.6)