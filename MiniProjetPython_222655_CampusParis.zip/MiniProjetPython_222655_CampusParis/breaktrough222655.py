def newBoard(n,p):
    board=[[]]*n
    for i in range (0,2):
        liste=[]
        for y in range(0,p):
            liste.append(1)
        board[i]=liste
    for i in range (2,(n-2)):
        liste=[]
        for y in range(0,p):
            liste.append(0)
        board[i]=liste
    for i in range ((n-2),(n)):
        liste=[]
        for y in range(0,p):
            liste.append(2)
        board[i]=liste
    return board

def display(board,n,p):
    newBoard(n,p)
    for x in board:
        for i in x:
            if i == 0:
                print(".", '', end='')
            elif i == 2:
                print("o", '', end='')
            else:
                print("x",'', end='')
        print('\n')

def selectPawn(board,n,p,player):
    i = int(input("Entrer le numéro de la ligne où se trouve le pion à déplacer : "))
    while i > n or i == 0 :
        i = int(input("Entrer le numéro de la ligne où se trouve le pion à déplacer : "))
    j = int(input("Entrer le numéro de la colones où se trouve le pion à déplacer : "))
    a=p
    while j > a or j == 0:
        j = int(input("Entrer le numéro de la colones où se trouve le pion à déplacer : "))
    if player==0:
        while board[i-1][j-1]==2 or board[i-1][j-1]==0 :
            if board[i-1][j-1]==2:
                print("Le pion que vous avez selectionner appartient à l'adversaire")
            if board[i-1][j-1]==0:
                print("Vous avez selectionné une case vide")
            i = int(input("Entrer le numéro de la ligne où se trouve le pion à déplacer : "))
            while i > n:
                i = int(input("Entrer le numéro de la ligne où se trouve le pion à déplacer : "))
            j = int(input("Entrer le numéro de la colones où se trouve le pion à déplacer : "))
            while j > p:
                j = int(input("Entrer le numéro de la colones où se trouve le pion à déplacer : "))

    if player==1:
        while board[i-1][j-1]==0 or board[i - 1][j - 1] == 1 :
            if board[i - 1][j - 1] == 1:
                print("Le pion que vous avez selectionner appartient à l'adversaire")
            if board[i-1][j-1]==0:
                print("Vous avez selectionné une case vide")
            i = int(input("Entrer le numéro de la ligne où se trouve le pion à déplacer : "))
            while i > n:
                i = int(input("Entrer le numéro de la ligne où se trouve le pion à déplacer : "))
            j = int(input("Entrer le numéro de la colones où se trouve le pion à déplacer : "))
            while j > p:
                j = int(input("Entrer le numéro de la colones où se trouve le pion à déplacer : "))

    return i,j

def selectPawnComputer(board,n,p,player):
    import random
    i = random.randint(1,n)
    while i > n:
        i = random.randint(1,n)
    j = random.randint(1,p)
    a=p
    while (j > a):
        j = random.randint(1,p)
    if player == 1:
        while board[i-2][j-1]==2 or board[i - 1][j - 1] == 1 or board[i-1][j-1] == 0:
            i = random.randint(1, n)
            while i > n:
                i = random.randint(1, n)
            j = random.randint(1, p)
            while j > p:
                j = random.randint(1, p)

    return i,j

def where(board,n,p,player,i,j):
    a=0
    if player==0:
        y = int(input("Entrer le numéro de a colonne où vous souhaiter placer votre pion"))
        if i<n:
            a=i+1
        while board[a-1][y-1]==1 or y==0:
            print("Vous ne pouvez pas placer ce pion là-bas")
            y= int(input("Entrer le numéro de a colonne où vous souhaiter placer votre pion"))
        while board[a-1][y-1]==2 and (y==j):
            print("Vous ne pouvez pas placer ce pion là-bas")
            y = int(input("Entrer le numéro de a colonne où vous souhaiter placer votre pion"))
        while (y<j-1) or (y>j+1) or (y > p) or y==0:
            print("Vous ne pouvez pas placer ce pion là-bas")
            y = int(input("Entrer le numéro de a colonne où vous souhaiter placer votre pion"))
    if player==1:
        y = int(input("Entrer le numéro de a colonne où vous souhaiter placer votre pion"))
        while y == 0:
            y = int(input("Entrer le numéro de a colonne où vous souhaiter placer votre pion"))
        if i>1:
            a=i-1
        while board[a-1][y-1]==1 or y==0 or board[a-1][y-1]==2:
            print("Vous ne pouvez pas placer ce pion là-bas")
            y= int(input("Entrer le numéro de a colonne où vous souhaiter placer votre pion"))
        while board[a-1][y-1]==1 and y==j :
            print("Vous ne pouvez pas placer ce pion là-bas")
            y = int(input("Entrer le numéro de a colonne où vous souhaiter placer votre pion"))
        while (y<j-1) or (y>j+1) or (y > p):
            print("Vous ne pouvez pas placer ce pion là-bas")
            y = int(input("Entrer le numéro de a colonne où vous souhaiter placer votre pion"))
    x=i
    return x,y

def whereComputer(board,n,p,player,i,j):
    import random
    if player==1:
        y = random.randint(1, p)
        while board[i - 2][y - 1] == 2:
            y = random.randint(1, p)
        while board[i - 2][y - 1] == 1 and y == j:
            y = random.randint(1, p)
        while (y<j-1) or (y>j+1) or (y > p) or board[i - 2][y - 1] == 2  :
            y = random.randint(1, p)
            while board[i - 2][y - 1] == 1 and y == j:
                y = random.randint(1, p)

        print("Entrer le numéro de a colonne où vous souhaiter placer votre pion",y)
        x=i

    return x,y

def ChangePlayer(player):
    if player==0:
        NewPlayer=player+1
    if player==1:
        NewPlayer=player-1
    return NewPlayer

def winner(board,Nbr_pions1,Nbr_pions2):
    while Nbr_pions1==0 and Nbr_pions2!=0:
        print("Le Joueur 2 est le gagnant ")
    while Nbr_pions2==0 and Nbr_pions1!=0:
        print("Le Joueur 1 est le gagnant ")


def breaktrough(n,p):
    board=newBoard(n,p)
    display(board,n,p)
    print("")
    Nbr_pions1=0
    Nbr_pions2=0
    for i in range (n):
        Nbr_pions1+=board[i].count(1)
    for i in range(n):
        Nbr_pions2+=board[i].count(2)
    player=0
    i=0
    Choose_A_Version=int(input("Si vous souhaitez jouer contre l'ordinateur taper(1), contre votre invité taper (2)"))
    while  Choose_A_Version!=1 and Choose_A_Version!=2:
        Choose_A_Version = int(
            input("Si vous souhaitez jouer contre l'ordinateur taper(1), contre votre invité taper (2)"))
    while board[0].count(2)==0 and board[n-1].count(1)==0 and Nbr_pions1!=0 and Nbr_pions2!=0 and Choose_A_Version==2:
        print("Joueur", player+1,":")
        i,j=selectPawn(board,n,p,player)
        if player==0:
            if j==p:
                while board[i][j-1]==1 and board[i][j]==1:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
                while board[i][j-1]==2 and [i][j-2]==1:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
            if j==1:
                while board[i][j-1]==1 and board[i][j]==1:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
                while board[i][j-1]==2 and board[i][j]==1 :
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
            if j<p and j>1:
                while board[i][j - 1] == 1 and board[i][j] == 1 and board[i][j - 2] == 1:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
                while board[i][j-1]==2 and board[i][j-2]==1 and board[i][j]==1:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
        if player==1:
            if j==p:
                while board[i-2][j-1]==2 and board[i-2][j-2]==2:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
                while board[i-2][j-1]==1 and board[i-2][j-2]==2:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
            if j==1:
                while board[i-2][j-1]==2 and board[i-2][j]==2:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
                while board[i-2][j-1]==2 and board[i-2][j]==1:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
            if j<p and j>1:
                while board[i - 2][j - 1] == 2 and board[i - 2][j] == 2 and board[i - 2][j - 2] == 2:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
                while board[i-2][j-1]==1 and board[i-2][j-2]==2 and board[i-2][j]==2:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)

        x,y=where(board,n,p,player,i,j)
        if player==0 :
            board[i-1][j-1]=0
            x+=1
            board[x-1][y-1]=1
        if player==1:
            board[i-1][j-1]=0
            x-=1
            board[x-1][y-1]=2

        for i in range(n):
            Nbr_pions1 += board[i].count(1)
        for i in range(n):
            Nbr_pions2 += board[i].count(2)
        display(board,n,p)
        print("")
        player=ChangePlayer(player)
        while Nbr_pions1 == 0 and Nbr_pions2 != 0:
            print("Le Joueur 2 est le gagnant ")
        while Nbr_pions2 == 0 and Nbr_pions1 != 0:
            print("Le Joueur 1 est le gagnant ")
        if board[n - 1].count(1) == 1:
            print("Le Joueur 1 est le gagnant ")
        if board[0].count(2) == 1:
            print("Le Joueur 2 est le gagnant")
    while board[0].count(2) == 0 and board[n - 1].count(1) == 0 and Nbr_pions1 != 0 and Nbr_pions2 != 0 and Choose_A_Version == 1:
        if player==0:
            print("Joueur", player + 1, ":")
            i, j = selectPawn(board, n, p, player)
            if j==p:
                while board[i][j-1]==1 and board[i][j-2]==1:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
                while board[i][j-1]==2 and board[i][j-2]==1:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
            if j==1:
                while board[i][j-1]==1 and board[i][j]==1:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
                while board[i][j-1]==2 and board[i][j]==1:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
            if j<p and j>1:
                while board[i][j - 1] == 1 and board[i][j] == 1 and board[i][j - 2] == 1:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
                while board[i][j-1]==2 and board[i][j-2]==1 and board[i][j]==1:
                    print("Ce pion ne peut pas bouger")
                    i, j = selectPawn(board, n, p, player)
            x, y = where(board, n, p, player, i, j)
        if player==1:
            print("Joueur", player + 1, "( L'ordinateur ):")
            i, j = selectPawnComputer(board, n, p, player)
            if j==p:
                while board[i-2][j-1]==2 and board[i-2][j-2]==2:
                    i, j = selectPawnComputer(board, n, p, player)
                while board[i-2][j-1]==1 and board[i-2][j-2]==2:
                    i, j = selectPawnComputer(board, n, p, player)

            if j==1:
                while board[i-2][j-1]==2 and board[i-2][j]==2:
                    i, j = selectPawnComputer(board, n, p, player)
                while board[i-2][j-1]==1 and board[i-2][j]==2:
                    i, j = selectPawnComputer(board, n, p, player)

            if j<p and j>1:
                while board[i - 2][j - 1] == 2 and board[i - 2][j] == 2 and board[i - 2][j - 2] == 2:
                    i, j = selectPawnComputer(board, n, p, player)
                while board[i-2][j-1]==1 and board[i-2][j-2]==2 and board[i-2][j]==2:
                    i, j = selectPawnComputer(board, n, p, player)
            print("Entrer le numéro de la ligne où se trouve le pion à déplacer: ", i)
            print("Entrer le numéro de la colonne où se trouve le pion à déplacer: ", j)
            x, y = whereComputer(board, n, p, player, i, j)


        if player == 0:
            board[i - 1][j - 1] = 0
            x += 1
            board[x - 1][y - 1] = 1
        if player == 1:
            board[i - 1][j - 1] = 0
            x -= 1
            board[x - 1][y - 1] = 2

        for i in range(n):
            Nbr_pions1 += board[i].count(1)
        for i in range(n):
            Nbr_pions2 += board[i].count(2)
        display(board, n, p)
        print("")
        player = ChangePlayer(player)
        while Nbr_pions1 == 0 and Nbr_pions2 != 0:
            print("L'ordinateur est le gagnant ")
        while Nbr_pions2 == 0 and Nbr_pions1 != 0:
            print("Le Joueur 1 est le gagnant ")
        if board[n - 1].count(1) == 1:
            print("Le Joueur 1 est le gagnant ")
        if board[0].count(2) == 1:
            print("L'ordinateur est le gagnant ")




















n=int(input("Saisissez le nombre de lignes  : "))
while n<=4:
    n=int(input("Saisissez un nombre de lignes supérieur à 4 merci : "))
p=int(input("Saisissez le nombre de colones : "))
while p<=1:
    p=int(input("Saisissez un nombre de lignes supérieur à 4 merci : "))
print("Votre plateau sera donc constitué de ",n,"lignes et de ",p," colonnes")
breaktrough(n,p)

print("")
print("")
print("NOUMSI FOTSO Neil Jordan id: 222655 , Campus Paris")