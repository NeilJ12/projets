def newBoard(n):
    board=[[]]*n
    for i in range (0,2):
        liste=[]
        for y in range(0,n):
            liste.append(0)
        board[i]=liste
    for i in range (2,(n-2)):
        liste=[]
        for y in range(0,n):
            liste.append(0)
        board[i]=liste
    for i in range ((n-2),(n)):
        liste=[]
        for y in range(0,n):
            liste.append(0)
        board[i]=liste
    return board

def displayV2(board,n):
    for x in board:
        for i in x:
            if i == 0:
                print(".", '', end='')
            if i == 1:
                print("o", '', end='')
            if i==2:
                print("x",'', end='')
            if i==3:
                print(".",'',end='')
            if i==4:
                print(".",'',end='')
            if i==7:
                print(".",'',end='')

        print('\n')

def notFinishV2(board,n,player):
    case_dispo=0
    for o in range (1,(n+1)):
        case_dispo+=board[o-1].count(0)
    if player==0:
        case_neutre=0
        case_dispoV2 = 0
        for o in range(1, (n + 1)):
            case_dispoV2 += board[o - 1].count(3)
            case_neutre += board[o - 1].count(7)
        if case_dispo==0 and case_dispoV2==0 and case_neutre==0:
            t=False
        else:
            t=True
    if player==1:
        case_neutre=0
        case_dispoV2 = 0
        for o in range(1, (n + 1)):
            case_dispoV2 += board[o - 1].count(4)
            case_neutre += board[o -1].count(7)
        if case_dispo==0 and case_dispoV2==0  and case_neutre==0:
            t=False
        else:
            t=True

    return t

def selectSquareV2(board,n,player):
    i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
    while i > n or i == 0:
        i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
    j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))
    while j > n or j == 0:
        j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))
    if player==0:
        while board[i-1][j-1]!=0 and board[i-1][j-1]!=3 and board[i-1][j-1]!=7 :
            if board[i-1][j-1]==4:
                print("Cette case est situé dans la direction d'un pion adversaire")
            if board[i-1][j-1]==1:
                print("Vous avez déjà un pion situé sur cette case ")
            i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
            while i > n or i == 0:
                i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
            j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))
            while j > n or j == 0:
                j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))
    if player==1:
        while board[i-1][j-1]!=0 and board[i-1][j-1]!=4  and board[i-1][j-1]!=7 :
            if board[i-1][j-1]==3:
                print("Cette case est situé dans la direction d'un pion adversaire")
            if board[i-1][j-1]==2:
                print("Vous avez déjà un pion situé sur cette case ")
            i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
            while i > n or i == 0:
                i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
            j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))
            while j > n or j == 0:
                j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))

    return i,j

def UseforSelectIA(board,n,player,b):
    import random

    case_dispo = 0
    case_neutre = 0
    case_dispoV2 = 0
    for o in range(1, (n + 1)):
        case_dispo += board[o - 1].count(0)
        case_dispoV2 += board[o - 1].count(b)
        case_neutre += board[o - 1].count(7)
    if case_dispo != 0 and case_neutre <= case_dispo:
        i = random.randint(1, (n))
        j = random.randint(1, (n))
        while board[i - 1][j - 1] != 0:
            i = random.randint(1, (n))
            j = random.randint(1, (n))
    if case_neutre != 0 and case_neutre > case_dispo:
        i = random.randint(1, (n))
        j = random.randint(1, (n))
        while board[i - 1][j - 1] != 7:
            i = random.randint(1, (n))
            j = random.randint(1, (n))

    if case_neutre == 0 and case_dispo == 0 and case_dispoV2 != 0:
        i = random.randint(1, (n))
        j = random.randint(1, (n))
        while board[i - 1][j - 1] != b:
            i = random.randint(1, (n))
            j = random.randint(1, (n))

    return i,j

def selectSquareV2Computer(board,n,player):
    if player==0:
        i,j=UseforSelectIA(board,n,player,3)

    if player == 1:
        i,j=UseforSelectIA(board, n, player, 4)


    return i, j


def UseForUpdate(board,n,i,j,player,b):
    i-=1
    j-=1
    if player == 0:
        board[i][j] = 1
    if player == 1:
        board[i][j] = 2

    if i-1 >= 0 and board[i-1][j] != 1 and board[i-1][j] != 2 and board[i-1][j] != b:
        if board[i-1][j] == 7:
            board[i-1][j] = b
        else:
            board[i - 1][j] += b

    if i+1 < n  and board[i+1][j] != 1 and board[i+1][j] != 2 and board[i+1][j] != b:
        if board[i+1][j] == 7:
            board[i+1][j] = b
        else:
            board[i + 1][j] += b

    if j-1 >= 0 and board[i][j-1] != 1 and board[i][j-1] != 2 and board[i][j-1] != b:
        if board[i][j-1] == 7:
            board[i][j - 1] = b
        else:
            board[i][j - 1] += b

    if j+1 < n and board[i][j+1] != 1 and board[i][j+1] != 2 and board[i][j+1] != b:
        if board[i][j+1] == 7:
            board[i][j + 1] = b
        else:
            board[i][j + 1] += b

    if i-1 >= 0 and j-1 >= 0 and board[i-1][j-1] != 1 and board[i-1][j-1] != 2 and board[i-1][j-1] != b:
        if board[i-1][j-1] == 7:
            board[i - 1][j - 1] = b
        else:
            board[i - 1][j - 1] += b

    if i+1 < n and j+1 < n and board[i+1][j+1] != 1 and board[i+1][j+1] != 2 and board[i+1][j+1] != b:
        if board[i+1][j+1] == 7:
            board[i + 1][j + 1] = b
        else:
            board[i + 1][j + 1] += b

    if i-1 >= 0 and j+1 < n and board[i-1][j+1] != 1 and board[i-1][j+1] != 2  and board[i-1][j+1] != b:
        if board[i-1][j+1] == 7:
            board[i - 1][j + 1] = b
        else:
            board[i - 1][j + 1] += b

    if i+1 < n and j-1 >= 0 and board[i+1][j-1] != 1 and board[i+1][j-1] != 2 and board[i+1][j-1] != b:
        if board[i+1][j-1] == 7:
            board[i + 1][j - 1] = b
        else:
            board[i + 1][j - 1] += b


def updateV2(board,n,i,j,player):
    if player == 0:
        UseForUpdate(board,n,i,j,player,3)
    if player == 1:
        UseForUpdate(board,n,i,j,player,4)

def ChangePlayer(player):
    if player==0:
        NewPlayer=player+1
    if player==1:
        NewPlayer=player-1
    return NewPlayer

def Pleiadis(n):
    board=newBoard(n)
    displayV2(board,n)
    player=0
    Choose_A_Version = int(input("Pour jouer contre votre invité taper (1), pour jouer contre l'IA taper(2)"))
    while Choose_A_Version != 1 and Choose_A_Version != 2:
        Choose_A_Version = int(input("Pour jouer contre votre invité taper (1), pour jouer contre l'IA taper(2)"))

    if Choose_A_Version ==1 :
        t=notFinishV2(board,n,player)
        while t == True:
            print("Joueur", player + 1, ":")
            i, j = selectSquareV2(board, n, player)
            updateV2(board, n, i, j, player)
            displayV2(board, n)
            player = ChangePlayer(player)
            t = notFinishV2(board, n, player)
        print("Le joueur", player + 1, ", vous ne pouvez plus placer un pion.")
        player = ChangePlayer(player)
        print("Le joueur", player + 1, "a gagné")

    if Choose_A_Version == 2 :
        ChoosePlayer=int(input("Pour commmencer à jouer taper (1) pour laisser l'IA jouer taper (2)"))
        if ChoosePlayer == 1:
            player=0
            t=notFinishV2(board,n,player)
            while t == True:
                if player == 0:
                    print("Joueur", player + 1, ":")
                    i,j = selectSquareV2(board,n,player)
                    updateV2(board, n, i, j, player)
                    displayV2(board, n)

                if player == 1:
                    print("Joueur", player + 1, ":")
                    i,j=selectSquareV2Computer(board,n,player)
                    print("Ligne : ", i)
                    print("Colonne : ", j)
                    updateV2(board, n, i, j, player)
                    displayV2(board, n)

                player = ChangePlayer(player)
                t = notFinishV2(board, n, player)
            print("Le joueur", player + 1, ", vous ne pouvez plus placer un pion.")
            player = ChangePlayer(player)
            print("Le joueur", player + 1, "a gagné")
        if ChoosePlayer == 2:
            player=0
            t=notFinishV2(board,n,player)
            while t == True:
                if player == 0:
                    print("Joueur", player + 1, "(L'IA):")
                    i, j = selectSquareV2Computer(board, n, player)
                    print("Ligne : ", i)
                    print("Colonne : ", j)
                    updateV2(board, n, i, j, player)
                    displayV2(board, n)

                if player == 1:
                    t=notFinishV2(board, n, player)
                    print("Joueur", player + 1, ":")
                    i, j = selectSquareV2(board, n, player)
                    updateV2(board, n, i, j, player)
                    displayV2(board, n)

                player = ChangePlayer(player)
                t = notFinishV2(board, n, player)
            print("Le joueur", player + 1, ", vous ne pouvez plus placer un pion.")
            player = ChangePlayer(player)
            print("Le joueur", player + 1, "a gagné")

n = int(input("Saisissez le nombre de lignes  : "))
while n <3:
    n = int(input("Saisissez un nombre de lignes supérieur à 2 merci : "))
print("Votre plateau sera donc constitué de ", n, "lignes et de ", n, " colonnes")
Pleiadis(n)

print("")
print("")
print("NOUMSI FOTSO Neil Jordan id: 222655 , Campus Paris")