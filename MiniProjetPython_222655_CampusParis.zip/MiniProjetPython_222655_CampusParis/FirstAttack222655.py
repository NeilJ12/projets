def newBoard(n):
    board=[[]]*n
    for i in range (0,2):
        liste=[]
        for y in range(0,n):
            liste.append(0)
        board[i]=liste
    for i in range (2,(n-2)):
        liste=[]
        for y in range(0,n):
            liste.append(0)
        board[i]=liste
    for i in range ((n-2),(n)):
        liste=[]
        for y in range(0,n):
            liste.append(0)
        board[i]=liste
    return board

def display(board,n):
    for x in board:
        for i in x:
            if i == 0:
                print(".", '', end='')
            if i == 1:
                print("o", '', end='')
            if i==2:
                print(".",'', end='')
        print('\n')

def displayV2(board,n):
    for x in board:
        for i in x:
            if i == 0:
                print(".", '', end='')
            if i == 1:
                print("o", '', end='')
            if i==2:
                print("x",'', end='')
            if i==3:
                print(".",'',end='')
            if i==4:
                print(".",'',end='')
            if i==7:
                print(".",'',end='')

        print('\n')

def notFinish(board,n):
    case_dispo=0
    for o in range (1,(n+1)):
        case_dispo+=board[o-1].count(0)
    if case_dispo == 0:
        t=False
    if case_dispo!=0:
        t=True
    return t

def notFinishV2(board,n,player):
    case_dispo=0
    for o in range (1,(n+1)):
        case_dispo+=board[o-1].count(0)
    if player==0:
        case_neutre=0
        case_dispoV2 = 0
        for o in range(1, (n + 1)):
            case_dispoV2 += board[o - 1].count(4)
        if case_dispo==0 and case_dispoV2==0:
            t=False
        else:
            t=True
    if player==1:
        case_neutre=0
        case_dispoV2 = 0
        for o in range(1, (n + 1)):
            case_dispoV2 += board[o - 1].count(3)
        if case_dispo==0 and case_dispoV2==0 :
            t=False
        else:
            t=True

    return t

def selectSquare(board,n):
    i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
    while i > n or i == 0:
        i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
    j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))
    while j > n or j == 0:
        j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))
    while board[i-1][j-1]!=0:
        if board[i-1][j-1]==1:
            print("Un pion est déjà sur cette case")
        if board[i-1][j-1]==2:
            print("Cette case est situé dans la direction d'un autre pion")
        i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
        while i > n or i == 0:
            i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
        j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))
        while j > n or j == 0:
            j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))
    return i,j

def selectSquareV2(board,n,player):
    i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
    while i > n or i == 0:
        i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
    j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))
    while j > n or j == 0:
        j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))
    if player==0:
        while board[i-1][j-1] == 1 or board[i-1][j-1]==7 or board[i-1][j-1] == 3  :
            if board[i-1][j-1]==1:
                print("Vous avez déjà un pion situé sur cette case ")
            if board[i-1][j-1] == 7:
                print("Cette case est à cheval à la direction de votre pion et celui de l'adversaire")
            if board[i-1][j-1] == 3:
                print("Un de vos pions est situé dans la direction de cette case ")
            i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
            while i > n or i == 0:
                i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
            j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))
            while j > n or j == 0:
                j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))

    if player==1:
        while board[i-1][j-1] == 1 or board[i-1][j-1]==7 or board[i-1][j-1] == 4  :
            if board[i-1][j-1]==1:
                print("Vous avez déjà un pion situé sur cette case ")
            if board[i-1][j-1] == 7:
                print("Cette case est à cheval à la direction de votre pion et celui de l'adversaire")
            if board[i-1][j-1] == 4:
                print("Un de vos pions est situé dans la direction de cette case")
            i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
            while i > n or i == 0:
                i = int(input("Entrer le numéro de la ligne de la case où vous voulez placer votre pion : "))
            j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))
            while j > n or j == 0:
                j = int(input("Entrer le numéro de la colones de la case où vous voulez placer votre pion : "))

    return i,j

def update(board,n,i,j):
    i-=1
    j-=1
    board[i]=[2]*n
    for a in range(n):
        if a!=i:
            board[a][j]=2
        continue

    for o in range (n):
        if i-o >= 0 and j-o >= 0:
            board[i-o][j-o]=2
        if i-o >= 0 and j+o < n:
            board[i - o][j + o] = 2
        if i+o < n and j-o >= 0:
            board[i + o][j - o] = 2
        if i+o < n and j+o < n:
            board[i + o][j + o] = 2
    board[i][j] = 1

def updateV2(board,n,i,j,player):
    i-=1
    j-=1
    if player == 0:
        board[i][j] = 1
        for a in range(n):
            if board[i][a] != 1 and board[i][a] != 2 and board[i][a] != 3 and board[i][a] != 7:
                board[i][a] += 3
            if board[a][j] != 1 and board[a][j] != 2 and board[a][j] != 3 and board[a][j] != 7:
                board[a][j] += 3
            if i-a >= 0 and j-a >=0 and board[i-a][j-a] != 1 and board[i-a][j-a] != 2 and board[i-a][j-a] != 7 and board[i-a][j-a] != 3:
                board[i-a][j-a] += 3
            if i-a >= 0 and j+a < n and board[i-a][j+a] != 1 and board[i-a][j+a] != 2 and board[i-a][j+a] != 7 and board[i-a][j+a] != 3:
                board[i-a][j+a] += 3
            if i+a < n and j-a >= 0 and board[i+a][j-a] != 1 and board[i+a][j-a] != 2 and board[i+a][j-a] != 7 and board[i+a][j-a] != 3:
                board[i+a][j-a] += 3
            if i+a < n and j+a < n and board[i+a][j+a] != 1 and board[i+a][j+a] != 2 and board[i+a][j+a] != 7 and board[i+a][j+a] != 3:
                board[i+a][j+a] += 3

    if player == 1:
        board[i][j] = 2
        for a in range(n):
            if board[i][a] != 1 and board[i][a] != 2 and board[i][a] != 4 and board[i][a] != 7:
                board[i][a] += 4
            if board[a][j] != 1 and board[a][j] != 2 and board[a][j] != 4 and board[a][j] != 7:
                board[a][j] += 4
            if i - a >= 0 and j - a >= 0 and board[i - a][j - a] != 1 and board[i - a][j - a] != 2 and board[i - a][j - a] != 7 and board[i - a][j - a] != 4:
                board[i - a][j - a] += 4
            if i - a >= 0 and j + a < n and board[i - a][j + a] != 1 and board[i - a][j + a] != 2 and board[i - a][j + a] != 7 and board[i - a][j + a] != 4:
                board[i - a][j + a] += 4
            if i + a < n and j - a >= 0 and board[i + a][j - a] != 1 and board[i + a][j - a] != 2 and board[i + a][j - a] != 7 and board[i + a][j - a] != 4:
                board[i + a][j - a] += 4
            if i + a < n and j + a < n and board[i + a][j + a] != 1 and board[i + a][j + a] != 2 and board[i + a][j + a] != 7 and board[i + a][j + a] != 4:
                board[i + a][j + a] += 4

def ChangePlayer(player):
    if player==0:
        NewPlayer=player+1
    if player==1:
        NewPlayer=player-1
    return NewPlayer

def FirstAttack(n):
    board=newBoard(n)
    display(board,n)
    Choose_A_Version=int(input("Pour jouer la version de jeu classique taper (1), pour jouer avec les couleurs taper(2)"))
    while Choose_A_Version!=1 and Choose_A_Version!=2:
        Choose_A_Version = int(input("Pour jouer la version de jeu classique taper (1), pour jouer avec les couleurs taper(2)"))
    print("")
    player = 0
    if Choose_A_Version==1:
        t=notFinish(board,n)
        while t==True:
            print("Joueur", player + 1, ":")
            i,j=selectSquare(board,n)
            update(board,n,i,j)
            display(board,n)
            t=notFinish(board,n)
            player=ChangePlayer(player)
        print("Le joueur", player + 1, ", vous ne pouvez plus placer un pion.")
        player=ChangePlayer(player)
        print("Le joueur", player+1,"a gagné")
    if Choose_A_Version==2:
        t=notFinishV2(board,n,player)
        while t==True:
            print("Joueur", player + 1, ":")
            i, j = selectSquareV2(board, n , player)
            updateV2(board, n, i, j,player)
            displayV2(board, n)
            player = ChangePlayer(player)
            t = notFinishV2(board, n,player)
        print("Le joueur", player + 1, ", vous ne pouvez plus placer un pion.")
        player = ChangePlayer(player)
        print("Le joueur", player + 1, "a gagné")




n = int(input("Saisissez le nombre de lignes  : "))
while n <3:
    n = int(input("Saisissez un nombre de lignes supérieur à 2 merci : "))
print("Votre plateau sera donc constitué de ", n, "lignes et de ", n, " colonnes")
FirstAttack(n)

print("")
print("")
print("NOUMSI FOTSO Neil Jordan id: 222655 , Campus Paris")