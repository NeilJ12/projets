print("Bienvenue sur GAMEPLAYA")
print("")
print("Nous vous proposons trois jeux dans ce programme")
print("Le premier est un jeu de Dame ( Breakthrough), le second s'appelle FirstAttack et le dernier s'appelle Pleiadis")
ChooseGame=int(input("Pour jouer à breakthrough taper(1), pour jouer à FirstAttack taper (2) pour jouer à pleaidis (3) ou taper (4) si vous ne voulez plus jouer : "))

while ChooseGame != 1 and ChooseGame != 2 and ChooseGame != 3 and ChooseGame != 4:
    ChooseGame = int(input("Pour jouer à breakthrough taper(1), pour jouer à FirstAttack taper (2) pour jouer à pleaidis (3) ou taper (4) si vous ne voulez plus jouer : "))

while ChooseGame == 1 or ChooseGame == 2 or ChooseGame == 3:
    if ChooseGame == 1:
        Regle=int(input("Si vous voulez voir les règles avant de commencer à jouer taper(0) sinon taper (1) : "))
        while Regle != 1 and Regle != 0:
            Regle = int(input("Si vous voulez voir les règles avant de commencer à jouer taper(0) sinon taper (1) : "))
        if Regle == 0:
            print("Ce jeu a été conçu en 2000 par Dan Troyka.\n Deux joueurs s’affrontent sur un plateau rectangulaire de n lignes (n>4) et p colonnes,\n le premier possédant des pions blancs et le second des pions noirs.\n Au début de la partie,\n les pions du premier joueur occupent les deux premières lignes du plateau et ceux du second les deux dernières lignes.\n Les autres cases sont vides.")
            print("")
            print("Les blancs commencent, puis les joueurs vont à tour de rôle déplacer un de leur pion en respectant les différentes contraintes suivantes :\n On doit aller de l’avant, i.e. les pions blancs doivent aller vers le bas et les pions noirs vers le haut.\n On ne peut pas rester sur la même ligne.Un pion peut se déplacer vers une case libre si elle est adjacente orthogonalement ou en diagonale par rapport à sa position courante.\nUn pion peut se déplacer vers une case occupée par un pion adverse uniquement si elle est adjacente en diagonale par rapport à sa position courante.\n Elle « prend » alors ce pion.\nLa prise d’un pion n’est pas prioritaire par rapport à un déplacement vers une case vide. \nOn ne peut enchaîner plusieurs prises lors d’un même coup.\nUn pion ne peut en aucun cas se déplacer vers une case contenant un pion de la même couleur.")
            print("")
            print("Vous êtes prêt(e)(s) à jouer maintenant")

        print(" ")

        import breaktrough

    if ChooseGame == 2:
        Regle = int(input("Si vous voulez voir les règles avant de commencer à jouer taper(0) sinon taper (1) : "))
        while Regle != 1 and Regle != 0:
            Regle = int(input("Si vous voulez voir les règles avant de commencer à jouer taper(0) sinon taper (1) : "))
        if Regle == 0:
            print("")
            print("Ce jeu a été conçu par Frank Harary (date inconnue).\n Deux joueurs s’affrontent sur un plateau carré de n lignes et n colonnes, initialement vide.\n Dans la règle originale les joueurs jouent avec les mêmes pions (on proposera aussi une variante où ce n’est pas le cas).")
            print("")
            print("A tour de rôle les joueurs posent un pion sur une case vide du plateau de telle sorte que: \ncette case ne soit pas sur la même ligne qu’un pion déjà présent sur le plateau, \nla même colonne ou la même diagonale qu’un pion déjà présent sur le plateau")
            print("")
            print("Le gagnant est le dernier joueur à pouvoir poser un pion. \nAutrement dit, dès qu’un joueur ne peut plus poser de pion il a perdu.")
            print("Vous êtes maintenant prêt(e)(s) à jouer")

        print(" ")

        import FirstAttack

    if ChooseGame == 3:
        Regle = int(input("Si vous voulez voir les règles avant de commencer à jouer taper(0) sinon taper (1) : "))
        while Regle != 1 and Regle != 0:
            Regle = int(input("Si vous voulez voir les règles avant de commencer à jouer taper(0) sinon taper (1) : "))
        if Regle == 0:
            print("")
            print("Ce jeu a été conçu par en 2002 par Christian Watkins et Jan Kristian Haugland.\n Deux joueurs s’affrontent sur un plateau carré de n lignes et n colonnes, le premier possédant des pions blancs et le second des pions noirs. \nAu début de la partie le plateau est vide.")
            print("")
            print("Les blancs commencent, puis à tour de rôle les joueurs posent un de leurs pions sur une case vide \n du plateau de telle sorte que pour cette case le nombre de pions adjacents de l’adversaire\n (orthogonalement ou en diagonale) présents sur le plateau soit inférieur ou égal au nombre de pions\n adjacents du joueur.")
            print("")
            print("Le gagnant est le dernier joueur à pouvoir poser un pion. Autrement dit, dès qu’un joueur ne peut \nplus poser de pion il a perdu")

        print("")

        import Pleiadis

    ChooseGame = int(input(
        "Pour jouer à breakthrough taper(1), pour jouer à FirstAttack taper (2) pour jouer à pleaidis (3) ou taper (4) si vous ne voulez plus jouer : "))
    while ChooseGame != 1 and ChooseGame != 2 and ChooseGame != 3 and ChooseGame != 4:
        ChooseGame = int(input(
            "Pour jouer à breakthrough taper(1), pour jouer à FirstAttack taper (2) pour jouer à pleaidis (3) ou taper (4) si vous ne voulez plus jouer : "))


        print("")
        print("")
        print("NOUMSI FOTSO Neil Jordan id: 222655 , Campus Paris")