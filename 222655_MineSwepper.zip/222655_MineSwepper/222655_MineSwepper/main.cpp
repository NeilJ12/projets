//
//  main.cpp
//  222655_MineSwepper
//
//  Created by Neil Jordan Noumsi Fotso on 09/02/2018.
//  Copyright © 2018 222655 Campus Paris. All rights reserved.
//


#include <iostream>
using namespace std;

#define mine -1;
#define vide -2;

int **creer_tab(int a, int b);
void Afficher_solution(int a, int b, int **tab);
void initialiser (int a, int b, int **tab );
int Aleatoire(int a, int b){
    return rand()%(b-a) +a;
}
void placer_mines(int a, int b, int **tab, int m);
int dans_plateau(int x, int y,int a, int b);
int mines_voisines(int a, int b, int **tab, int x, int y);
void afficher_plateau(int a, int b, int **tab);
void remplissage(int a, int b, int **tab, int abs, int ods);
void propagation(int a, int b, int **tab, int **test_tab, int **front_tab, int abs, int ods);
void jouer_coup(int a, int b, int **tab,int **front_tab, int abs, int ods);
int cond_gagne(int a, int b, int **tab, int **front_tab, int abs, int ods, int z);

int main(int argc, const char * argv[]) {
    // insert code here...
    int p;
    int n;
    int z;
    cout << "Bienvenu sur le Champ de Mines\n";
    cout <<"Nous allons maintenant définir la taille de votre champ de mines.";
    cout << "\nChoissisez le nombre de lignes : ";
    cin >> n;
    if (n<3) {
        cout << "\nChoissisez le nombre de lignes : ";
        cin >> n;
    }
    cout <<"Choississez le nombre de colonnes : ";
    cin >>p;
    if (p<3) {
        cout << "\nChoissisez le nombre de colonnes : ";
        cin >> p;
    }
    
    
    int** board;
    int** front_board;
    int** test_board;
    board=creer_tab(n, p);
    front_board=creer_tab(n, p);
    test_board=creer_tab(n, p);
    
    initialiser(n, p, board);
    initialiser(n, p, front_board);
    initialiser(n, p, test_board);
    cout <<"Entrez votre nombre de mines : ";
    cin >> z;
    if (z>n*p || z==0) {
        cout << "\nEntrez votre nombre de mines : ";
        cin >> z;
    }
    cout << "Votre champ de mines aura donc : "<<n<<" lignes et "<<p<<" colonnes.\n";
    cout <<"Et miner par : "<<z<<" Mines\n\n";
    int jeu;
    placer_mines(n, p, board, z);
    for (int i=0; i<n; i++) {
        for (int j=0; j<p; j++) {
            remplissage(n, p, board, i, j);
        }
    }
    
    Afficher_solution(n, p, board);
    cout<<"\n\n";
    afficher_plateau(n, p, front_board);
    
    int ab;
    int od;
    jeu=1;
    while (jeu == 1) {
        cout << "\nEntrez le numéro de la ligne ( 0-"<<n-1<<") : ";
        cin >> ab;
        cout << "\nEntrez le numéro de la colonnes( 0-"<<p-1<<") : ";
        cin >> od;
        int test;
        test=dans_plateau(ab, od, n, p);
        while (test==0) {
            cout << "\nEntrez le numéro de la ligne ( 0-"<<n-1<<") : ";
            cin >> ab;
            cout << "\nEntrez le numéro de la colonnes( 0-"<<p-1<<") : ";
            cin >> od;
            test=dans_plateau(ab, od, n, p);
        }
        jouer_coup(n, p, board, front_board, ab, od);
        if (board[ab][od]==-3 ) {
            propagation(n, p, board, test_board, front_board, ab, od);
        }
        afficher_plateau(n, p, front_board);
        jeu=cond_gagne(n, p, board,front_board, ab, od, z);
    }
    cout<<"\n";
    cout<<"VOICI LE CHAMP DE MINES\n";
    Afficher_solution(n, p, board);
    return 0;
}


int **creer_tab(int a, int b)
{
    int **tab;
    tab = new int*[a];
    for(unsigned int i = 0; i < b; i++)
    {
        tab[i] = new int[b];
    }
    return tab;
}


void Afficher_solution(int a, int b, int **tab)
{
    int i = 0, j = 0;
    
    for (i = 0 ; i < a ; i++)
    {
        for (j = 0 ; j < b ; j++)
        {
            if (tab[i][j] == 0 || tab[i][j] == -3 ) {
                cout<<"["<<"-"<<"]";
            }
            else if (tab[i][j] == -1){
                cout<<"["<<"X"<<"]";
            }
            else{
                cout<<"["<<tab[i][j]<<"]";
            }
        }
        cout<<"\n";
    }
}

void initialiser (int a, int b, int **tab )
{
    int i = 0, j = 0;
    
    for (i = 0 ; i < a ; i++)
    {
        for (j = 0 ; j < b ; j++)
        {
            tab[i][j] = vide;
        }
    }
}

void placer_mines(int a, int b, int **tab, int m)
{
    int i = 0;
    int ab;
    int od;
    for (i = 0 ; i < m ; i++)
    {
        ab=Aleatoire(0, a);
        od=Aleatoire(0, b);
        while (tab[ab][od]==-1) {
            ab=Aleatoire(0, a);
            od=Aleatoire(0, b);
        }
        tab[ab][od] = mine;
    }
}

int dans_plateau(int x, int y,int a, int b)
{
    if (x>=0 && x<a && y>=0 && y<b) {
        return 1;
    }
    else return 0;
}

int mines_voisines(int a, int b, int **tab, int x, int y)
{
    int vois;
    vois=0;
    if (x==0) {
        if (y==0) {
            if (tab[x+1][y]==-1) {
                vois+=1;
            }
            if (tab[x+1][y+1]==-1) {
                vois+=1;
            }
            if (tab[x][y+1]==-1) {
                vois+=1;
            }
        }
        else if (y==b-1) {
            if (tab[x+1][y]==-1) {
                vois+=1;
            }
            if (tab[x+1][y-1]==-1) {
                vois+=1;
            }
            if (tab[x][y-1]==-1) {
                vois+=1;
            }
        }
        else if (y>0 && y<b-1){
            if (tab[x+1][y]==-1) {
                vois+=1;
            }
            if (tab[x+1][y-1]==-1) {
                vois+=1;
            }
            if (tab[x][y-1]==-1) {
                vois+=1;
            }
            if (tab[x+1][y+1]==-1) {
                vois+=1;
            }
            if (tab[x][y+1]==-1) {
                vois+=1;
            }
        }
        return vois;
    }
    
    else if (x==a-1) {
        if (y==0) {
            if (tab[x-1][y]==-1) {
                vois+=1;
            }
            if (tab[x-1][y+1]==-1) {
                vois+=1;
            }
            if (tab[x][y+1]==-1) {
                vois+=1;
            }
        }
        else if (y==b-1) {
            if (tab[x-1][y]==-1) {
                vois+=1;
            }
            if (tab[x-1][y-1]==-1) {
                vois+=1;
            }
            if (tab[x][y-1]==-1) {
                vois+=1;
            }
        }
        else if (y>0 && y<b-1){
            if (tab[x-1][y]==-1) {
                vois+=1;
            }
            if (tab[x-1][y-1]==-1) {
                vois+=1;
            }
            if (tab[x][y-1]==-1) {
                vois+=1;
            }if (tab[x-1][y+1]==-1) {
                vois+=1;
            }
            if (tab[x][y+1]==-1) {
                vois+=1;
            }
        }
        return vois;
    }
    
    else{
        if (y==0) {
            if (tab[x-1][y]==-1) {
                vois+=1;
            }
            if (tab[x-1][y+1]==-1) {
                vois+=1;
            }
            if (tab[x][y+1]==-1) {
                vois+=1;
            }
            if (tab[x+1][y]==-1) {
                vois+=1;
            }
            if (tab[x+1][y+1]==-1) {
                vois+=1;
            }
        }
        else if (y==b-1) {
            if (tab[x-1][y]==-1) {
                vois+=1;
            }
            if (tab[x-1][y-1]==-1) {
                vois+=1;
            }
            if (tab[x][y-1]==-1) {
                vois+=1;
            }
            if (tab[x+1][y]==-1) {
                vois+=1;
            }
            if (tab[x+1][y-1]==-1) {
                vois+=1;
            }
        }
        else if (y>0 && y<b-1){
            if (tab[x-1][y]==-1) {
                vois+=1;
            }
            if (tab[x-1][y-1]==-1) {
                vois+=1;
            }
            if (tab[x][y-1]==-1) {
                vois+=1;
            }if (tab[x-1][y+1]==-1) {
                vois+=1;
            }
            if (tab[x][y+1]==-1) {
                vois+=1;
            }
            if (tab[x+1][y]==-1) {
                vois+=1;
            }
            if (tab[x+1][y-1]==-1) {
                vois+=1;
            }
            if (tab[x+1][y+1]==-1) {
                vois+=1;
            }
        }
        return vois;
    }
}



void remplissage(int a, int b, int **tab, int abs, int ods)
{
    if (tab[abs][ods]!=-1 && tab[abs][ods]==-2 ) {
        tab[abs][ods]=mines_voisines(a, b, tab, abs, ods);
        if (tab[abs][ods]==0) {
            tab[abs][ods]=-3;
        }
    }
    else if (tab[abs][ods]==-2) {
        tab[abs][ods]=-3;
    }
}


void jouer_coup(int a, int b, int **tab,int **front_tab, int abs, int ods)
{
    if (tab[abs][ods]==-1) {
        for (int i=0; i<a; i++) {
            for (int j=0; j<b; j++) {
                if (tab[i][j]==-1) {
                    front_tab[i][j]=-1;
                }
            }
        }
    }
    else{
        if (tab[abs][ods]==-3) {
            front_tab[abs][ods]=0;
        }
        else{
            front_tab[abs][ods]=tab[abs][ods];
        }
    }
}


void afficher_plateau(int a, int b, int **tab)
{
    int i = 0, j = 0;
    
    for (i = 0 ; i < a ; i++)
    {
        for (j = 0 ; j < b ; j++)
        {
            if (tab[i][j] == -1) {
                cout<<"["<<"X"<<"]";
            }
            else if (tab[i][j] == -2){
                cout<<"["<<" "<<"]";
            }
            else if (tab[i][j]==0){
                cout<<"["<<"-"<<"]";
            }
            else{
                cout<<"["<<tab[i][j]<<"]";
            }
        }
        cout<<"\n";
    }
}

void propagation(int a, int b, int **tab,int **test_tab, int **front_tab, int x, int y)
{
    if (x==0) {
        if (y==0) {
            if (tab[x+1][y]==-3 && tab[x+1][y]!=test_tab[x+1][y]) {
                front_tab[x+1][y]=0;
                test_tab[x+1][y]=tab[x+1][y];
                propagation(a, b, tab, test_tab, front_tab, x+1, y);
            }
            if (tab[x+1][y]!=-3) {
                front_tab[x+1][y]=tab[x+1][y];
            }
            
            if (tab[x+1][y+1]==-3 && tab[x+1][y+1]!=test_tab[x+1][y+1] ) {
                front_tab[x+1][y+1]=0;
                test_tab[x+1][y+1]= tab[x+1][y+1];
                propagation(a, b, tab, test_tab, front_tab, x+1, y+1);
            }
            if (tab[x+1][y+1]!=-3) {
                front_tab[x+1][y+1]=tab[x+1][y+1];
            }
            
            if (tab[x][y+1]==-3 && tab[x][y+1]!=test_tab[x][y+1]) {
                front_tab[x][y+1]=0;
                test_tab[x][y+1]=tab[x][y+1];
                propagation(a, b, tab, test_tab, front_tab, x, y+1);
            }
            if (tab[x][y+1]!=-3) {
                front_tab[x][y+1]=tab[x][y+1];
            }
        }
        else if (y==b-1) {
            if (tab[x+1][y]==-3 && tab[x+1][y]!=test_tab[x+1][y] ) {
                front_tab[x+1][y]=0;
                test_tab[x+1][y]=tab[x+1][y];
                propagation(a, b, tab, test_tab, front_tab, x+1, y);
            }
            if (tab[x+1][y]!=-3) {
                front_tab[x+1][y]=tab[x+1][y];
            }
            
            if (tab[x+1][y-1]==-3 && tab[x+1][y-1]!=test_tab[x+1][y-1]){
                front_tab[x+1][y-1]=0;
                test_tab[x+1][y-1]=tab[x+1][y-1];
                propagation(a, b, tab, test_tab, front_tab, x+1, y-1);
            }
            if (tab[x+1][y-1]!=-3) {
                front_tab[x+1][y-1]=tab[x+1][y-1];
            }
            
            if (tab[x][y-1]==-3 && tab[x][y-1]!=test_tab[x][y-1]) {
                front_tab[x][y-1]=0;
                test_tab[x][y-1]=tab[x][y-1];
                propagation(a, b, tab, test_tab, front_tab, x, y-1);
            }
            if (tab[x][y-1]!=-3) {
                front_tab[x][y-1]=tab[x][y-1];
            }
        }
        else{
            if (tab[x+1][y]==-3  && tab[x+1][y]!=test_tab[x+1][y]) {
                front_tab[x+1][y]=0;
                test_tab[x+1][y]=tab[x+1][y];
                propagation(a, b, tab, test_tab, front_tab, x+1, y);
            }
            if (tab[x+1][y]!=-3) {
                front_tab[x+1][y]=tab[x+1][y];
            }
            
            if (tab[x+1][y-1]==-3 && tab[x][y]!=test_tab[x+1][y-1]) {
                front_tab[x+1][y-1]=0;
                test_tab[x+1][y-1]=tab[x+1][y-1];
                propagation(a, b, tab, test_tab, front_tab, x+1, y-1);
            }
            if (tab[x+1][y-1]!=-3) {
                front_tab[x+1][y-1]=tab[x+1][y-1];
            }
            
            if (tab[x][y-1]==-3 && test_tab[x][y-1]!=tab[x][y-1]) {
                front_tab[x][y-1]=0;
                test_tab[x][y-1]=tab[x][y-1];
                propagation(a, b, tab, test_tab, front_tab, x, y-1);
            }
            if (tab[x][y-1]!=-3) {
                front_tab[x][y-1]=tab[x][y-1];
            }
            
            if (tab[x+1][y+1]==-3 && test_tab[x+1][y+1]!=tab[x+1][y+1]) {
                front_tab[x+1][y+1]=0;
                test_tab[x+1][y+1]=tab[x+1][y+1];
                propagation(a, b, tab, test_tab, front_tab, x+1, y+1);
            }
            if (tab[x+1][y]!=-3) {
                front_tab[x+1][y]=tab[x+1][y];
            }
            
            if (tab[x][y+1]==-3 && test_tab[x][y+1]!=tab[x][y+1]) {
                front_tab[x][y+1]=0;
                test_tab[x][y+1]=tab[x][y+1];
                propagation(a, b, tab, test_tab, front_tab, x, y+1);
            }
            if (tab[x][y+1]!=-3) {
                front_tab[x][y+1]=tab[x][y+1];
            }
        }
    }
    
    else if (x==a-1) {
        if (y==0) {
            if (tab[x-1][y]==-3 && test_tab[x-1][y]!=tab[x-1][y]) {
                front_tab[x-1][y]=0;
                test_tab[x-1][y]=tab[x-1][y];
                propagation(a, b, tab, test_tab, front_tab, x-1, y);
            }
            if (tab[x-1][y]!=-3) {
                front_tab[x-1][y]=tab[x-1][y];
            }
            
            if (tab[x-1][y+1]==-3 && test_tab[x-1][y+1]!=tab[x-1][y+1]) {
                front_tab[x-1][y+1]=0;
                test_tab[x-1][y+1]=tab[x-1][y+1];
                propagation(a, b, tab, test_tab, front_tab, x-1, y+1);
            }
            if (tab[x-1][y+1]!=-3) {
                front_tab[x-1][y+1]=tab[x-1][y+1];
            }
            
            if (tab[x][y+1]==-3 && test_tab[x][y+1]!=tab[x][y+1]) {
                front_tab[x][y+1]=0;
                test_tab[x][y+1]=tab[x][y+1];
                propagation(a, b, tab, test_tab, front_tab, x, y+1);
            }
            if (tab[x][y+1]!=-3) {
                front_tab[x][y+1]=tab[x][y+1];
            }
        }
        else if (y==b-1) {
            if (tab[x-1][y]==-3 && test_tab[x-1][y]!=tab[x-1][y]) {
                front_tab[x-1][y]=0;
                test_tab[x-1][y]=tab[x-1][y];
                propagation(a, b, tab, test_tab, front_tab, x-1, y);
            }
            if (tab[x-1][y]!=-3) {
                front_tab[x-1][y]=tab[x-1][y];
            }
            
            if (tab[x-1][y-1]==-3 && test_tab[x-1][y-1]!=tab[x-1][y-1]) {
                front_tab[x-1][y-1]=0;
                test_tab[x-1][y-1]=tab[x-1][y-1];
                propagation(a, b, tab, test_tab, front_tab, x-1, y-1);
            }
            if (tab[x-1][y-1]!=-3) {
                front_tab[x-1][y-1]=tab[x-1][y-1];
            }
            
            if (tab[x][y-1]==-3 && test_tab[x][y-1]!=tab[x][y-1]) {
                front_tab[x][y-1]=0;
                test_tab[x][y-1]=tab[x][y-1];
                propagation(a, b, tab, test_tab, front_tab, x, y-1);
            }
            if (tab[x][y-1]!=-3) {
                front_tab[x][y-1]=tab[x][y-1];
            }
        }
        else{
            
            if (tab[x-1][y]==-3 && test_tab[x-1][y]!=tab[x-1][y]) {
                front_tab[x-1][y]=0;
                test_tab[x-1][y]=tab[x-1][y];
                propagation(a, b, tab, test_tab, front_tab, x-1, y);
            }
            if (tab[x-1][y]!=-3) {
                front_tab[x-1][y]=tab[x-1][y];
            }
            
            if (tab[x-1][y-1]==-3 && test_tab[x-1][y-1]!=tab[x-1][y-1]) {
                front_tab[x-1][y-1]=0;
                test_tab[x-1][y-1]=tab[x-1][y-1];
                propagation(a, b, tab, test_tab, front_tab, x-1, y-1);
            }
            if (tab[x-1][y-1]!=-3) {
                front_tab[x-1][y-1]=tab[x-1][y-1];
            }
            
            if (tab[x][y-1]==-3 && test_tab[x][y-1]!=tab[x][y-1]) {
                front_tab[x][y-1]=0;
                test_tab[x][y-1]=tab[x][y-1];
                propagation(a, b, tab, test_tab, front_tab, x, y-1);
            }
            if (tab[x][y-1]!=-3) {
                front_tab[x][y-1]=tab[x][y-1];
            }
            
            if (tab[x-1][y+1]==-3 && test_tab[x-1][y+1]!=tab[x-1][y+1]) {
                front_tab[x-1][y+1]=0;
                test_tab[x-1][y+1]=tab[x-1][y+1];
                propagation(a, b, tab, test_tab, front_tab, x-1, y+1);
            }
            if (tab[x-1][y+1]!=-3) {
                front_tab[x-1][y+1]=tab[x-1][y+1];
            }
            
            if (tab[x][y+1]==-3 && test_tab[x][y+1]!=tab[x][y+1]) {
                front_tab[x][y+1]=0;
                test_tab[x][y+1]=tab[x][y+1];
                propagation(a, b, tab, test_tab, front_tab, x, y+1);
            }
            if (tab[x][y+1]!=-3) {
                front_tab[x][y+1]=tab[x][y+1];
            }
        }
    }
    
    else{
        if (y==0) {
            
            if (tab[x-1][y]==-3 && test_tab[x-1][y]!=tab[x-1][y]) {
                front_tab[x-1][y]=0;
                test_tab[x-1][y]=tab[x-1][y];
                propagation(a, b, tab, test_tab, front_tab, x-1, y);
            }
            if (tab[x-1][y]!=-3) {
                front_tab[x-1][y]=tab[x-1][y];
            }
            
            if (tab[x-1][y+1]==-3 && test_tab[x-1][y+1]!=tab[x-1][y+1]) {
                front_tab[x-1][y+1]=0;
                test_tab[x-1][y+1]=tab[x-1][y+1];
                propagation(a, b, tab, test_tab, front_tab, x-1, y+1);
            }
            if (tab[x-1][y+1]!=-3) {
                front_tab[x-1][y+1]=tab[x-1][y+1];
            }
            
            if (tab[x][y+1]==-3 && test_tab[x][y+1]!=tab[x][y+1]) {
                front_tab[x][y+1]=0;
                test_tab[x][y+1]=tab[x][y+1];
                propagation(a, b, tab, test_tab, front_tab, x, y+1);
            }
            if (tab[x][y+1]!=-3) {
                front_tab[x][y+1]=tab[x][y+1];
            }
            
            if (tab[x+1][y+1]==-3 && test_tab[x+1][y+1]!=tab[x+1][y+1]) {
                front_tab[x+1][y+1]=0;
                test_tab[x+1][y+1]=tab[x+1][y+1];
                propagation(a, b, tab, test_tab, front_tab, x+1, y+1);
            }
            if (tab[x+1][y+1]!=-3) {
                front_tab[x+1][y+1]=tab[x+1][y+1];
            }
            
            if (tab[x+1][y]==-3 && test_tab[x+1][y]!=tab[x+1][y]) {
                front_tab[x+1][y]=0;
                test_tab[x+1][y]=tab[x+1][y];
                propagation(a, b, tab, test_tab, front_tab, x+1, y);
            }
            if (tab[x+1][y]!=-3) {
                front_tab[x+1][y]=tab[x+1][y];
            }
            
        }
        else if (y==b-1) {
            
            if (tab[x-1][y]==-3 && test_tab[x-1][y]!=tab[x-1][y]) {
                front_tab[x-1][y]=0;
                test_tab[x-1][y]=tab[x-1][y];
                propagation(a, b, tab, test_tab, front_tab, x-1, y);
            }
            if (tab[x-1][y]!=-3) {
                front_tab[x-1][y]=tab[x-1][y];
            }
            
            if (tab[x-1][y-1]==-3 && test_tab[x-1][y-1]!=tab[x-1][y-1]) {
                front_tab[x-1][y-1]=0;
                test_tab[x-1][y-1]=tab[x-1][y-1];
                propagation(a, b, tab, test_tab, front_tab, x-1, y-1);
            }
            if (tab[x-1][y-1]!=-3) {
                front_tab[x-1][y-1]=tab[x-1][y-1];
            }
            
            if (tab[x][y-1]==-3 && test_tab[x][y-1]!=tab[x][y-1]) {
                front_tab[x][y-1]=0;
                test_tab[x][y-1]=tab[x][y-1];
                propagation(a, b, tab, test_tab, front_tab, x, y-1);
            }
            if (tab[x][y-1]!=-3) {
                front_tab[x][y-1]=tab[x][y-1];
            }
            
            if (tab[x+1][y]==-3 && test_tab[x+1][y]!=tab[x+1][y]) {
                front_tab[x+1][y]=0;
                test_tab[x+1][y]=tab[x+1][y];
                propagation(a, b, tab, test_tab, front_tab, x+1, y);
            }
            if (tab[x+1][y]!=-3) {
                front_tab[x+1][y]=tab[x+1][y];
            }
            
            if (tab[x+1][y-1]==-3 && test_tab[x+1][y-1]!=tab[x+1][y-1]) {
                front_tab[x+1][y-1]=0;
                test_tab[x+1][y-1]=tab[x+1][y-1];
                propagation(a, b, tab, test_tab, front_tab, x+1, y-1);
            }
            if (tab[x+1][y-1]!=-3) {
                front_tab[x+1][y-1]=tab[x+1][y-1];
            }
        }
        else{
            
            if (tab[x-1][y]==-3 && test_tab[x-1][y]!=tab[x-1][y]) {
                front_tab[x-1][y]=0;
                test_tab[x-1][y]=tab[x-1][y];
                propagation(a, b, tab, test_tab, front_tab, x-1, y);
            }
            if (tab[x-1][y]!=-3) {
                front_tab[x-1][y]=tab[x-1][y];
            }
            
            if (tab[x-1][y-1]==-3 && test_tab[x-1][y-1]!=tab[x-1][y-1]) {
                front_tab[x-1][y-1]=0;
                test_tab[x-1][y-1]=tab[x-1][y-1];
                propagation(a, b, tab, test_tab, front_tab, x-1, y-1);
            }
            if (tab[x-1][y-1]!=-3) {
                front_tab[x-1][y-1]=tab[x-1][y-1];
            }
            
            if (tab[x][y-1]==-3 && test_tab[x][y-1]!=tab[x][y-1]) {
                front_tab[x][y-1]=0;
                test_tab[x][y-1]=tab[x][y-1];
                propagation(a, b, tab, test_tab, front_tab, x, y-1);
            }
            if (tab[x][y-1]!=-3) {
                front_tab[x][y-1]=tab[x][y-1];
            }
            
            if (tab[x-1][y+1]==-3 && test_tab[x-1][y+1]!=tab[x-1][y+1]) {
                front_tab[x-1][y+1]=0;
                test_tab[x-1][y+1]=tab[x-1][y+1];
                propagation(a, b, tab, test_tab, front_tab, x-1, y+1);
            }
            if (tab[x-1][y+1]!=-3) {
                front_tab[x-1][y+1]=tab[x-1][y+1];
            }
            
            if (tab[x][y+1]==-3 && test_tab[x][y+1]!=tab[x][y+1]) {
                front_tab[x][y+1]=0;
                test_tab[x][y+1]=tab[x][y+1];
                propagation(a, b, tab, test_tab, front_tab, x, y+1);
            }
            if (tab[x][y+1]!=-3) {
                front_tab[x][y+1]=tab[x][y+1];
            }
            
            if (tab[x+1][y]==-3 && test_tab[x+1][y]!=tab[x+1][y]) {
                front_tab[x+1][y]=0;
                test_tab[x+1][y]=tab[x+1][y];
                propagation(a, b, tab, test_tab, front_tab, x+1, y);
            }
            if (tab[x+1][y]!=-3) {
                front_tab[x+1][y]=tab[x+1][y];
            }
            
            if (tab[x+1][y-1]==-3 && test_tab[x+1][y-1]!=tab[x+1][y-1])  {
                front_tab[x+1][y-1]=0;
                test_tab[x+1][y-1]=tab[x+1][y-1];
                propagation(a, b, tab, test_tab, front_tab, x+1, y-1);
            }
            if (tab[x+1][y-1]!=-3) {
                front_tab[x+1][y-1]=tab[x+1][y-1];
            }
            
            if (tab[x+1][y+1]==-3 && test_tab[x+1][y+1]!=tab[x+1][y+1]) {
                front_tab[x+1][y+1]=0;
                test_tab[x+1][y+1]=tab[x+1][y+1];
                propagation(a, b, tab, test_tab, front_tab, x+1, y+1);
            }
            if (tab[x+1][y+1]!=-3) {
                front_tab[x+1][y+1]=tab[x+1][y+1];
            }
        }
    }
}

int cond_gagne(int a, int b, int **tab, int **front_tab, int abs, int ods, int z)
{
    int case_jouable=0;
    for (int i=0; i<a; i++) {
        for (int j=0; j<b; j++) {
            if (front_tab[i][j]==-2) {
                case_jouable=case_jouable+1;
            }
        }
    }
    if (case_jouable==z) {
        cout<<"VICTOIRE!!!!\n";
        return 0;
    }
    
    else if (tab[abs][ods]==-1) {
        cout<<"Vous avez perdu!!\n";
        return 1;
    }
    else
    {
        return 1;
    }
}

